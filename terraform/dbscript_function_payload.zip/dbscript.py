import json 
import boto3
dynamodb = boto3.resource ('dynamodb')
table = dynamodb.table('web-views')
def lambda_handler (event, context):
    response = table.get_item(
        Key={
            'id': '1'
        }
    )
    
    return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': (response['Item']['resume'])
        }

    views = response ['Item' ]['views']
    viewa = views +1
    print(views)
    response = table.put_item(Item={
    'id': '1',
    'views': views
    })

    return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': (response['Item']['resume'])
        }